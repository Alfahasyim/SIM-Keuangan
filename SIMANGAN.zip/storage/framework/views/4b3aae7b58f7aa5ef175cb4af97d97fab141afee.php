
<?php $__env->startSection('content'); ?>
<div class="row wrapper border-bottom white-bg page-heading">
  <div class="col-lg-8">
    <h2>Orderan</h2> 
  </div>
  <div class="col-lg-4">
    <div class="title-action">
      
      
      <a href="/admin/ListOrderMasuk/<?php echo e($data_order->id); ?>/LK/Print" target="_blank" class="btn btn-primary"><i class="fa fa-print"></i> Print </a>
    </div>
  </div>
</div>
<div class="row">
  <div class="col-lg-12">
    <div class="wrapper wrapper-content animated fadeInRight">
      <div class="ibox-content p-xl">
        <div class="row">
          <div class="col-sm-6">
            <h5>From:</h5>
            <address>
              <strong><?php echo e($data_order->pelanggan->nama_pelanggan); ?></strong>
            </address>
          </div>

          <div class="col-sm-6 text-right">
            <h4>Order Number</h4>
            <h4 class="text-navy"><?php echo e($data_order->no_order); ?></h4> 
            <p>
              <span><strong>Order Date:</strong><?php echo e($data_order->tanggal_order); ?></span><br/> 
            </p>
          </div>
        </div>

        <div class="table-responsive m-t">
          <table class="table invoice-table">
            <thead> 
					  <tr> 
					  	<th>Item List</th>
					  	<th>Quantity</th>
					  	<th>Unit Price</th>
					  	<th>Total</th> 
					  </tr>
            </thead>
            <tbody> 
            <?php $__currentLoopData = $data_detail_order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				      <tr> 
				        <td><?php echo e($item->barang->nama_barang); ?></td> 
				        <td><?php echo e($item->qty); ?></td> 
				        <td>Rp.<?php echo e(number_format($item->harga_jual_pcs)); ?></td> 
				        <td>Rp.<?php echo e(number_format($item->sub_total_harga_jual_pcs)); ?></td>  
				      </tr>
				    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
            </tbody>
          </table>
        </div><!-- /table-responsive -->

        <table class="table invoice-total">
          <tbody>
          <tr>
            <td><strong>Total :</strong></td>
            <td>Rp.<?php echo e(number_format($data_order->jumlah_total_harga_jual)); ?></td>
          </tr> 
          </tbody>
        </table>  
      </div>
    </div>
  </div>
</div>
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp7.2.9\htdocs\SIMANGAN\resources\views/admin/LaporanKeluar.blade.php ENDPATH**/ ?>