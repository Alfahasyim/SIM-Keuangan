
<?php $__env->startSection('content'); ?>
<div class="row">
<div class="col-lg-12">
    <div class="ibox ">
        <div class="ibox-title">
            <h5>Dashboard</h5>
            
        </div>
        <div class="ibox-content">
          <div class="row"> 
            <div class="col-lg-12">
                <ul class="stat-list">
                  <li><h1>SELAMAT DATANG <?php echo e(Auth::User()->nama_user); ?></h1></li>
                  <li>
                      <h2 class="no-margins">Total Order : <?php echo e($total_order); ?></h2> 
                  </li> <li>
                      <h2 class="no-margins">Total Pendapatan : Rp.<?php echo e(number_format($order->sum('subtot_laba_bersih'))); ?></h2> 
                  </li>  
                </ul>
            </div>
          </div>
        </div>
    </div>
    </div>
</div>
<script type="text/javascript">
    $(document).ready(function() {
        
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp7.2.9\htdocs\SIMANGAN\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>